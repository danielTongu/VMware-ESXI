# Get-TodaysDate.ps1
Get-Date -Format "dddd, MMMM dd, yyyy"
