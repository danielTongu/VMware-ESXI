# Get-Processes.ps1
Get-Process
