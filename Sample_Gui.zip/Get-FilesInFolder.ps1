# Get-FilesInFolder.ps1
Add-Type -AssemblyName System.Windows.Forms

$folderDialog = New-Object System.Windows.Forms.FolderBrowserDialog
$folderDialog.Description = "Select a folder to list its files"

if ($folderDialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
    $folderPath = $folderDialog.SelectedPath
    $files = Get-ChildItem -Path $folderPath -File

    if ($files.Count -eq 0) {
        "No files found in the folder."
    } else {
        $files | Select-Object -ExpandProperty Name
    }
}
