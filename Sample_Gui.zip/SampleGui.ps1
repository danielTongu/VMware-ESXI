# Created by Jesus Rodriguez 

# loads the Windows Forms library so Gui elements can be used 
Add-Type -AssemblyName System.Windows.Forms

# --------------- Functions -----------------------
function SystemProcesses {
    $output = & "$PSScriptRoot\Get-Processes.ps1" | Select-Object -First 5 | Out-String
    [System.Windows.Forms.MessageBox]::Show($output, "Running Processes")
}

function TodaysDate {
    $output = & "$PSScriptRoot\Get-TodaysDate.ps1" | Out-String
    [System.Windows.Forms.MessageBox]::Show($output, "Todays date")
}

function FilesInFolder {
    $output = & "$PSScriptRoot\Get-FilesInFolder.ps1" | Out-String
    [System.Windows.Forms.MessageBox]::Show($output, "Files in Folder")
}

# --------------- Gui Setup -----------------------
$form = New-Object System.Windows.Forms.Form
$form.Text = "Sample Gui"
$form.Size = New-Object System.Drawing.Size(300,150)
$form.StartPosition = "CenterScreen"

# --------------- Buttons -----------------------
$button1 = New-Object System.Windows.Forms.Button
$button1.Text = "Processes"
$button1.Location = New-Object System.Drawing.Point(100,0)
$button1.Add_Click({ SystemProcesses })
$form.Controls.Add($button1)

$button2 = New-Object System.Windows.Forms.Button
$button2.Text = "Date"
$button2.Location = New-Object System.Drawing.Point(100,30)
$button2.Add_Click({ TodaysDate })
$form.Controls.Add($button2)

$button3 = New-Object System.Windows.Forms.Button
$button3.Text = "Files In Folder"
$button3.Location = New-Object System.Drawing.Point(100,60)
$button3.Add_Click({ FilesInFolder })
$form.Controls.Add($button3)

# --------------- Display The Gui -----------------------
$form.ShowDialog()