﻿# Written by Nathan White
# 3/20/19
# The purpose of this script is build the courseInfo object for IT436 class, and pass courseInfo
# to New-CourseVMs. The courseInfo object is defined as:
#       startStudents          int             starting student number
#       endStudents            int             ending student number
#       classFolder            string          folder for the class VMs
#       dataStore              string          which datastore to build the VMs on
#       servers                custom object   collection of servers to build
#             servername       string          name of the server
#             template         string          name of the template
#             customiszation   string          customization script
#             adapters         custom object   collection of network adapters for the server
#                  adapter  string          name of the network adapter
#
# 
# Within the student folder, the following virtual machines will be created and connected to a private student network:
#    LANWin
#    LANKali 
#    LANMeta
# Additionally, the students will also have the following virtual machines created and connected to the VM_Network so they will have internet access.
#    PubWin
#    PubKali

# The student will have the ability to start, stop, and view the console of these VMs.

# there are three input parameters for the start student number, ending student number,
# and the datastore to use
param (
    [int]$startStudents = 1,
    [int]$endStudents = 1,
    [string]$datastoreName
)

# import common functions
Import-Module $HOME'\Google Drive\VMware Scripts\VmFunctions.psm1'

ConnectTo-VMServer

# 
$sessionManager = Get-View ($DefaultVIServer.ExtensionData.Content.SessionManager)

# Store current session key
$currentSessionKey = $sessionManager.CurrentSession.Key

foreach ($session in $sessionManager.SessionList) {
    # Ignore vpxd-extension logins as well as the current session
    if($session.UserName -notmatch "vpxd-extension" -and $session.key -ne $currentSessionKey) {
        $session | Select Username, IpAddress, UserAgent, @{"Name"="APICount";Expression={$Session.CallCount}}, LoginTime | Export-Csv .\AllUserLoginTimes.csv
    }
}